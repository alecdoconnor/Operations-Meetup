import Foundation

/// Generate a random string with characters a-z, 0-9
///
/// - Parameter characterCount: pass in the length of the string required
/// - Returns: An `n` character random string
func generateString(_ characterCount: Int) -> String {
    
    let characters = Array("abcdefghijklmnopqrstuvwxyz1234567890")
    var randomString = ""
    for _ in 0..<characterCount {
        randomString.append(characters.randomElement()!)
    }
    return randomString
}


/// Begin guessing a password. This will take 36^n guesses on average, where 36 is the number of characters in a-z0-9
/// This is purposely not a more complicated solution and is not the best password guesser. For example, we may guess the same string more than once and therefore waste resources. This is just used to test BlockOperations
///
/// - Parameter password: A password to guess with characters a-z, 0-9
/// - Returns: How many guesses it took
func guess(password: String) -> Int {
    
    let characterCount = password.count
    
    var currentGuess = ""
    var guesses = 0
    while password != currentGuess {
        guesses += 1
        currentGuess = generateString(characterCount)
    }
    
    print("   Successfully guessed password \"\(currentGuess)\" in \(guesses) guess\(guesses == 1 ? "" : "es")")
    return guesses
}

// Hold onto a single BlockOperation for each password
var operations = [Operation]()

// Passwords to guess
let passwordsToGuess = ["a", "8", "hi", "i", "go", "to", "the", "zoo"]

// A handler for verifying that all other operations are completed
var completionOperation = Operation()

// Create all BlockOperations, add them to the operations array, and set them as dependencies of the completionOperation
for (i, password) in passwordsToGuess.enumerated() {
    let operation = BlockOperation {
        print("🕓 Begin New Guess #\(i+1) (\(password))")
        guess(password: password)
        print("✅ Ending Operation #\(i+1)")
    }
    operations.append(operation)
}

// We need to know when it is all finished, so add this completion block to the completion operation
completionOperation.completionBlock = {
    print("💥 Successfully guessed all passwords!")
}

// Create a queue to handle the operations
let queue = OperationQueue()
// 0 = unlimited, 1 = syncronous (one-at-a-time)
// Try some different values for the maximum number of opeations to be performed at once. Pay attention to the console's output and the order of operations
queue.maxConcurrentOperationCount = 0

// Get the party started 🎉🥳
queue.addOperation(completionOperation)
queue.addOperations(operations, waitUntilFinished: false)
