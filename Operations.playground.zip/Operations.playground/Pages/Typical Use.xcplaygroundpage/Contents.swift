import Foundation

/// This enum will be used for setting state of the AsyncOperation class
enum AsyncState: String {
    case ready = "isReady"
    case executing = "isExecuting"
    case finished = "isFinished"
}


/// A reusable Operation subclass that adds asyncronous capability
/// - Note: This should be subclassed for each unique task required. It should not (typically) be used directly
class AsyncOperation: Operation {
    
    // All AsyncOperations must define themselves as such
    override var isAsynchronous: Bool { return true }
    
    // State of operation instance
    var state: AsyncState = .ready {
        willSet {
            willChangeValue(forKey: state.rawValue)
            willChangeValue(forKey: newValue.rawValue)
        }
        didSet {
            didChangeValue(forKey: state.rawValue)
            didChangeValue(forKey: oldValue.rawValue)
        }
    }
    
    // State variable overrides
    override var isExecuting: Bool { return state == .executing }
    override var isFinished: Bool { return state == .finished }
    
    
    // Overriding start, called at start of operation
    override func start() {
        guard !isCancelled else {
            state = .finished
            return
        }
        state = .ready
        main()
    }
    
    // Overriding main, called by start to perform operation's work
    override func main() {
        guard !isCancelled else {
            state = .finished
            return
        }
        state = .executing
    }
}



// Create a struct to hold a Developer's data

struct Developer {
    let name: String
    let title: String
    let needsCoffee: Bool
    let socialMedia: SocialMedia
    
    struct SocialMedia {
        let twitterHandle: String
        let github: String
    }
    
    func tellMeMore() {
        print("""
            Dev Summary:
            
            \(name) is a(n) \(title) who \(needsCoffee ? "needs coffee" : "needs a nap").
            You can reach out to him on Twitter at @\(socialMedia.twitterHandle) or check out his GitHub profile at https://github.com/\(socialMedia.github)
            """)
    }
}




// Gather and process the JSON at a given URL, turn it into a Developer object (or nil)
// The purpose of this function is to demonstrate that Operations can be used to `wrap` complex existing code in your project into a 3-line repeatable solution
func getDevData(url: URL) -> Developer? {
    if let devData = try? Data(contentsOf: url) {
        if let rawJson = try? JSONSerialization.jsonObject(with: devData, options: []) {
            print("Raw JSON: \n\(rawJson)\n")
            if let json = rawJson as? [String: Any] {
                if let name = json["name"] as? String,
                    let title = json["title"] as? String,
                    let needsCoffee = json["needsCoffee"] as? Bool,
                    let socialMedia = json["socialMedia"] as? [String: String],
                    let twitter = socialMedia["twitterHandle"],
                    let github = socialMedia["github"] {
                    
                    let socialMediaObject = Developer.SocialMedia(twitterHandle: twitter, github: github)
                    return Developer(name: name, title: title, needsCoffee: needsCoffee, socialMedia: socialMediaObject)
                }
            }
        }
    }
    return nil
}

// Create the URL that has JSON
let url = URL(string: "https://alecoconnor.com/sampleJSON/profile.json")!
getDevData(url: url)?.tellMeMore()


// Convert the function to an asyncronous verision with an @escaping completion block
func getDevDataAsync(from url: URL, completion: @escaping (_ dev: Developer?)->Void) {
    if let devData = try? Data(contentsOf: url) {
        if let rawJson = try? JSONSerialization.jsonObject(with: devData, options: []) {
            print("Raw JSON: \n\(rawJson)\n")
            if let json = rawJson as? [String: Any] {
                if let name = json["name"] as? String,
                    let title = json["title"] as? String,
                    let needsCoffee = json["needsCoffee"] as? Bool,
                    let socialMedia = json["socialMedia"] as? [String: String],
                    let twitter = socialMedia["twitterHandle"],
                    let github = socialMedia["github"] {
                    
                    let socialMediaObject = Developer.SocialMedia(twitterHandle: twitter, github: github)
                    completion(Developer(name: name, title: title, needsCoffee: needsCoffee, socialMedia: socialMediaObject))
                }
            }
        }
    }
    completion(nil)
}



/// This is how an AsyncOperation subclass is created. This is the part I often create for a specific data task, and it can be used to wrap the existing code you already use. It is a copy-paste-able almost entirely!
class DeveloperOperation: AsyncOperation {
    
    // Change the type of the response to what you need
    var response: Developer? = nil
    // Either include the error, or don't if you don't need tracking
    var error: String? = nil
    
    // Handle parameters that need to be injected
    private let url: URL
    
    // Set those same values in the initializer
    init(_ url: URL) {
        self.url = url
    }
    
    // This function is the main change. Leave the first few lines alone, and for your sanity, don't override `start()`
    override func main() {
        super.main()
        
        // We have to handle the logic for cancellations, and it is always possible that an operation cancels after it has started. It is on us to handle that case
        guard !isCancelled else {
            self.state = .finished
            return
        }
        
        // This is the part you change. Toss your code in right here:
        getDevDataAsync(from: url) { (developer) in
            
            // Use a `defer` to ensure you reset the state to .finished when you leave here
            defer {
                self.state = .finished
            }
            
            // You often can set these directly and end the logic, since we aren't worried about handling Optional logic here. You are still welcome to handle logic here.
            // The `defer` becomes useful when you might be returning early from an `if` or `guard` or `for` loop, for example
            self.response = developer
            // If you are using an error parameter, set it here
            // self.error = error
        }
    }
}



// Create a queue to handle the operations
// I often set this at a class's level, instead of in-line with the operation, to ensure that it is not dequeued in the middle of an operation
let queue = OperationQueue()

// Create your operation *(line 1)*
let operation = DeveloperOperation(url)
// Handle your operations completion block *(line 2, plus data handling)*
operation.completionBlock = {
    operation.response?.tellMeMore()
}


// Get the party started 🎉🥳 *(line 3)*
queue.addOperation(operation)


// There we go, now we can put this anywhere in your app with just three lines of code, plus your data handling!
// Have fun!
