import Foundation


/// This enum will be used for setting state of the AsyncOperation class
enum AsyncState: String {
    case ready = "isReady"
    case executing = "isExecuting"
    case finished = "isFinished"
}


/// A reusable Operation subclass that adds asyncronous capability
/// - Note: This should be subclassed for each unique task required. It should not (typically) be used directly
class AsyncOperation: Operation {
    
    // All AsyncOperations must define themselves as such
    override var isAsynchronous: Bool { return true }
    
    // State of operation instance
    var state: AsyncState = .ready {
        willSet {
            willChangeValue(forKey: state.rawValue)
            willChangeValue(forKey: newValue.rawValue)
        }
        didSet {
            didChangeValue(forKey: state.rawValue)
            didChangeValue(forKey: oldValue.rawValue)
        }
    }
    
    // State variable overrides
    override var isExecuting: Bool { return state == .executing }
    override var isFinished: Bool { return state == .finished }
    
    
    // Overriding start, called at start of operation
    override func start() {
        guard !isCancelled else {
            state = .finished
            return
        }
        state = .ready
        main()
    }
    
    // Overriding main, called by start to perform operation's work
    override func main() {
        guard !isCancelled else {
            state = .finished
            return
        }
        state = .executing
    }
}


/// A wrapper around the AsyncOperation and Decodable to quickly grab networked items and decode their JSON.
/// - T: This type will be Decodable and will be used to automatically decode the networked JSON
class NetworkOperation<T: Decodable>: AsyncOperation {
    
    var response: T? = nil
    /// Many subclasses of an AsyncOperaton can include both a `response` and `error` object.
    /// This can make handling error cases as easy as `guard error == nil else {...}`
    /// (We won't need this for this example)
    // var error: Error? = nil
    
    let request: URLRequest
    
    // The session used for the network data task
    let session = URLSession.shared
    
    // Initialize network operation with a URLRequest and an expected generic type
    init(request: URLRequest) {
        self.request = request
        super.init()
    }
    
    override func main() {
        super.main()
        
        guard !isCancelled else {
            print("Network Operation cancelled at start of main: \(request)")
            self.state = .finished
            return
        }
        
        // Call network request provided on initialization
        let task = session.dataTask(with: request) { [weak self] (data, _, error) in
            
            defer {
                // Set state to .finished upon exit, to alert those interested
                self?.state = .finished
            }
            
            // Check for cancellation
            guard !(self?.isCancelled ?? true) else {
                print("Network Operation cancelled after network request: \(String(describing: self?.request))")
                return
            }
            
            // Check that data exists and no errors were provided from network request
            guard let data = data,
                error == nil else {
                    print("Network operation cancelled, network request contained error: \(String(describing: error))")
                    return
            }
            
            // Decode JSON response as given type, otherwise print the error
            do {
                let decoder = JSONDecoder()
                self?.response = try decoder.decode(T.self, from: data)
            } catch {
                print("Error decoding type \(T.self);\n  \(error)")
            }
        }
        task.resume()
    }
}


// All Operations must be submitted to a queue to get started
let queue = OperationQueue()

// Unlimited concurrent operations. Set to 1 for a syncronous OperationQueue
queue.maxConcurrentOperationCount = 0

// A struct that can automatically decode JSON text into an object
struct Fruit: Decodable {
    var fruit: String
    var size: String
    var color: String
    
    func tellMeMore() {
        print("I am a \(size) and \(color) \(fruit)")
    }
}

print("Getting started!\n")

// Create a URLRequest for the NetworkOperation to get data. A factory method can be useful in creating these URLRequests for you in a single place in the app.
let fruitRequest = URLRequest(url: URL(string: "https://alecoconnor.com/sampleJSON/fruit.json")!)

// Create a NetworkOperation, inject the `Fruit` type into it (to make use of the data), and provide it the URLRequest from above (to get the data)
let fruitOperation = NetworkOperation<Fruit>(request: fruitRequest)

// We need to know when this is finished, so add some useful code to the completion block
fruitOperation.completionBlock = {
    fruitOperation.response?.tellMeMore()
    print("Operation Completed\n")
}

// Don't forget to _actuallly_ add the operation to the queue, otherwise you will be sitting there for a while
queue.addOperation(fruitOperation)


// Great! We successfully decoded a single type, but many JSON files use an array of data instead of just an object--whether or not this is always a good idea.
// Handling arrays at the root level of JSON is as easy as changing the <T> type being send to the Network Operation. Instead, use <[T]>

// Create the URLRequest again, notice the URL is slightly different
let fruitsRequest = URLRequest(url: URL(string: "https://alecoconnor.com/sampleJSON/fruits.json")!)

// Set up the network operation as before, but provide <[Fruit]> instead of <Fruit>
let fruitsOperation = NetworkOperation<[Fruit]>(request: fruitsRequest)

// We need to know when this is finished, so add some useful code to the completion block
fruitsOperation.completionBlock = {
    // You can access an operation from its own completionBlock! Be aware not to form a memory leak.
    // Unwrap the response, which should always be optional
    if let response = fruitsOperation.response {
        // response is now of type T? or [Fruit]?
        for fruit in response {
            fruit.tellMeMore()
        }
        print("Fruit Count: \(response.count)")
    }
    print("Operation Completed")
}

// Add it to the queue and wait for the magic to happen ✨
queue.addOperation(fruitsOperation)
